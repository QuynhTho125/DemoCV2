// ========================================
// Configuration - AI Recruitment Demo
// ========================================

const Config = {
    // ========================================
    // MODE SETTINGS
    // ========================================
    // Set to true to use Mock Data (Demo Mode)
    // Set to false to use Real API (Production)
    USE_MOCK_DATA: false,

    // Enable debug logging
    DEBUG: true,

    // ========================================
    // API ENDPOINTS
    // Configure your backend ML API URLs
    // ========================================
    API: {
        BASE_URL: 'http://localhost:5001/api',       // Flask server - luu CV, features
        XGB_URL: 'http://127.0.0.1:8000/predict',    // FastAPI server - XGBoost predict

        // CV Analysis Endpoints
        CV: {
            UPLOAD: '/cv/upload',           // POST - Upload CV file
            EXTRACT: '/cv/{id}/extract',    // GET - Get extracted data from ML
            ANALYZE: '/cv/{id}/analyze',    // POST - Analyze CV vs job
        },

        // Analysis Endpoints
        ANALYSIS: {
            RESULT: '/analysis/{id}',           // GET - Get analysis result
            EXPLANATION: '/analysis/{id}/explain', // GET - Get AI explanation
        },

        // XGBoost Endpoints (FastAPI port 8000)
        PREDICT: '/predict',            // POST - Du doan CV bang XGBoost (port 8000)
        FEATURES: '/features',          // GET  - Lay danh sach feature names
        PREPROCESS: '/preprocess',      // POST - Tien xu ly CV text -> TF-IDF vector (port 5001)

        // Survey Endpoints
        SURVEY: {
            SUBMIT: '/survey/submit',   // POST - Submit survey responses
            GOOGLE_SHEET_URL: 'https://script.google.com/macros/s/AKfycbyZeSl47m0fAI4iCEiXahT9xDT37bp-61Jt09FXAaQ3uzRmDTyruUoZ5eA8E0l1GSIK/exec',
        }
    },

    // ========================================
    // UI SETTINGS
    // ========================================
    UI: {
        // Animation durations (ms)
        ANIMATION: {
            FADE: 300,
            SLIDE: 400,
            PROCESSING_STEP: 600,
        },

        // Score thresholds for display
        SCORE: {
            HIGH: 80,       // Green - Excellent match
            MEDIUM: 60,     // Yellow - Good match
            LOW: 40,        // Red - Poor match
        }
    },

    // ========================================
    // FEATURE FLAGS
    // Enable/disable features
    // ========================================
    FEATURES: {
        ALLOW_CV_EDIT: true,        // Allow candidates to edit AI-extracted info
        SHOW_EXPLANATION: true,      // Show AI explainability section
        SHOW_DEVELOPMENT_TIPS: true, // Show development suggestions
        ENABLE_SURVEY: true,         // Enable post-process survey
        DEMO_HR_SIMULATION: true,    // Show "Simulate HR Response" button
    }
};

// Helper function to get API URL with parameters
Config.getApiUrl = function (endpoint, params = {}) {
    let url = this.API.BASE_URL + endpoint;

    // Replace path parameters
    Object.keys(params).forEach(key => {
        url = url.replace(`{${key}}`, params[key]);
    });

    return url;
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Config;
}
