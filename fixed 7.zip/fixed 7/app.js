// ========================================
// Main Application Controller
// Orchestrates all components and manages state
// ========================================

// ========================================
// GLOBAL APPLICATION STATE
// ========================================
const AppState = {
    // Current screen
    currentScreen: 1,

    // User consent
    consentGiven: false,
    consentTime: null,

    // Uploaded file
    uploadedFile: null,

    // CV data - duoc dien boi PDFService + CVAnalysisService
    currentCVId: null,
    rawCVText: null,
    cvTokens: [],
    parsedCVData: null,
    confirmedCVData: null,
    fileInfo: null,
    cvModified: false,

    // Analysis result - duoc dien boi Screen3 truoc khi chuyen sang Screen4
    analysisId: null,
    analysisResult: null,

    // Submission
    cvSubmitted: false,
    submittedAt: null,

    // Survey
    surveySubmitted: false
};

// Make state accessible globally for debugging
window.AppState = AppState;

// ========================================
// MAIN APPLICATION OBJECT
// ========================================
const App = {
    // Component references
    components: {
        screen1: Screen1Component,
        screen2: Screen2Component,
        screen3: Screen3Component,
        screen4: Screen4Component,
        screen5: Screen5Component
    },

    /**
     * Initialize the application
     */
    async init() {
        if (Config.DEBUG) {
            console.log('========================================');
            console.log('AI Recruitment Demo - Initializing...');
            console.log('========================================');
        }

        // Initialize first screen
        await this.components.screen1.init();

        // Setup navigation
        this.setupNavigation();

        // Setup global event handlers
        this.setupEventHandlers();

        // Update progress bar
        this.updateProgressBar();

        if (Config.DEBUG) {
            console.log('App initialized successfully!');
        }
    },

    /**
     * Navigate to a specific screen
     * @param {number} screenNumber - Screen number (1-5)
     */
    async goToScreen(screenNumber) {
        if (screenNumber < 1 || screenNumber > 5) return;

        // Cleanup current screen
        const currentComponent = this.components[`screen${AppState.currentScreen}`];
        if (currentComponent?.cleanup) {
            currentComponent.cleanup();
        }

        // Hide current screen
        document.getElementById(`screen${AppState.currentScreen}`).classList.remove('active');

        // Show new screen
        document.getElementById(`screen${screenNumber}`).classList.add('active');

        // Update state
        AppState.currentScreen = screenNumber;

        // Update progress bar
        this.updateProgressBar();

        // Initialize new screen
        const newComponent = this.components[`screen${screenNumber}`];
        if (newComponent?.init) {
            await newComponent.init();
        }

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });

        if (Config.DEBUG) {
            console.log(`[App] Navigated to Screen ${screenNumber}`);
        }
    },

    /**
     * Update progress bar dots
     */
    updateProgressBar() {
        const dots = document.querySelectorAll('.progress-dot');
        dots.forEach((dot, index) => {
            const screenNum = index + 1;
            dot.classList.remove('active', 'completed');

            if (screenNum === AppState.currentScreen) {
                dot.classList.add('active');
            } else if (screenNum < AppState.currentScreen) {
                dot.classList.add('completed');
            }
        });
    },

    /**
     * Setup navigation button handlers
     */
    setupNavigation() {
        // Screen 1 -> Screen 2
        const continueBtn1 = document.getElementById('continueBtn1');
        if (continueBtn1) {
            continueBtn1.addEventListener('click', async () => {
                if (this.components.screen1.canProceed()) {
                    await this.goToScreen(2);
                }
            });
        }

        // Progress dots click navigation (optional)
        document.querySelectorAll('.progress-dot').forEach(dot => {
            dot.addEventListener('click', async (e) => {
                const screenNum = parseInt(dot.dataset.screen);
                // Only allow going back, not forward
                if (screenNum < AppState.currentScreen) {
                    await this.goToScreen(screenNum);
                }
            });
        });
    },

    /**
     * Setup global event handlers
     */
    setupEventHandlers() {
        // Consent checkbox
        const consentCheckbox = document.getElementById('consentCheckbox');
        const checkboxWrapper = document.querySelector('.checkbox-wrapper');

        if (checkboxWrapper && consentCheckbox) {
            // Remove click listener - rely on native label behavior and Screen1 handler
            // checkboxWrapper.addEventListener('click', ...) 
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const modal = document.getElementById('successModal');
                if (modal?.classList.contains('active')) {
                    modal.classList.remove('active');
                }
            }
        });
    },

    /**
     * Reset the entire demo
     */
    /**
     * Reset the entire demo
     */
    async reset() {
        // Hide modal
        document.getElementById('successModal')?.classList.remove('active');

        // Reset state (DO NOT reset currentScreen here, let goToScreen handle it)
        Object.assign(AppState, {
            consentGiven: false,
            consentTime: null,
            uploadedFile: null,
            cvModified: false,
            cvSubmitted: false,
            submittedAt: null,
            surveySubmitted: false
        });

        // Reset UI elements
        const consentCheckbox = document.getElementById('consentCheckbox');
        if (consentCheckbox) consentCheckbox.checked = false;

        const continueBtn1 = document.getElementById('continueBtn1');
        if (continueBtn1) continueBtn1.disabled = true;

        // Reset upload UI
        const dropzone = document.getElementById('uploadDropzone');
        const uploadPreview = document.getElementById('uploadPreview');
        const uploadProcessing = document.getElementById('uploadProcessing');
        const uploadSection = document.querySelector('.upload-section');
        if (dropzone) dropzone.style.display = 'block';
        if (uploadPreview) uploadPreview.style.display = 'none';
        if (uploadProcessing) uploadProcessing.style.display = 'none';
        if (uploadSection) uploadSection.classList.remove('processing');

        // Reset survey
        this.components.screen5.reset();

        // Remove active class from ALL screens to be safe
        document.querySelectorAll('.screen').forEach(el => el.classList.remove('active'));

        // Go to screen 1 (this will add active class and set AppState)
        await this.goToScreen(1);

        if (Config.DEBUG) {
            console.log('[App] Demo reset complete');
        }
    }
};

// ========================================
// GLOBAL FUNCTIONS FOR HTML ONCLICK
// ========================================

function goToScreen(screenNumber) {
    App.goToScreen(screenNumber);
}

function toggleCheckbox() {
    const checkbox = document.getElementById('consentCheckbox');
    checkbox.checked = !checkbox.checked;
    checkbox.dispatchEvent(new Event('change'));
}

function simulateHRResponse() {
    Screen3Component.simulateHRResponse();
}

function completeSurvey() {
    Screen5Component.submit();
}

function endSession() {
    // Hide modal
    document.getElementById('successModal')?.classList.remove('active');

    // Reset and go back to Screen 1
    App.reset();
}


// ========================================
// INITIALIZE APP ON DOM READY
// ========================================
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
