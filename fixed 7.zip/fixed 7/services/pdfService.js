// ========================================
// PDF Service - Extract text + tokenize + basic CV parsing
// Frontend-only for demo
// ========================================

const PDFService = {
    currentPDFUrl: null,

    validateFile(file) {
    const errors = [];

    if (!file) {
        errors.push('Vui lòng chọn file');
        return { isValid: false, errors };
    }

    const fileName = (file.name || '').toLowerCase().trim();
    const mimeType = (file.type || '').toLowerCase().trim();

    const isPdfByMime = mimeType === 'application/pdf';
    const isPdfByExtension = fileName.endsWith('.pdf');

    if (!isPdfByMime && !isPdfByExtension) {
        errors.push('Chỉ chấp nhận file PDF (.pdf)');
    }

    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
        errors.push('File không được vượt quá 5MB');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
},

    async processCV(file) {
        const validation = this.validateFile(file);
        if (!validation.isValid) {
            throw new Error(validation.errors[0]);
        }

        const rawText = await this.extractTextFromPDF(file);
        const tokens = this.tokenizeText(rawText);

        // Dung Claude API de parse chinh xac hon
        let parsedCVData;
        try {
            parsedCVData = await this.parseCVWithClaude(rawText);
        } catch (e) {
            console.warn('[PDFService] Claude parse failed, fallback to regex:', e);
            parsedCVData = this.parseCVText(rawText, tokens);
        }

        const result = {
            fileInfo: {
                name: file.name,
                size: file.size,
                type: file.type,
                uploadedAt: new Date().toISOString()
            },
            rawText,
            tokens,
            parsedCVData,
            status: 'processed',
            message: 'PDF extracted and tokenized successfully.'
        };

        // Luu JSON len backend
        this.saveCVToServer(result.parsedCVData);

        return result;
    },

    async parseCVWithClaude(rawText) {
        const ANTHROPIC_API_KEY = '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\n';
        if (!ANTHROPIC_API_KEY) {
            throw new Error('Chua co API key. Nhan nut khoa o goc phai de nhap key.');
        }

        const prompt = `You are a CV content extractor. Extract ALL meaningful content from the CV below and return ONLY valid JSON, NO markdown, NO backticks, NO explanation.

CV TEXT:
${rawText.slice(0, 10000)}

Rules:
- Extract EVERYTHING meaningful — do NOT summarize, do NOT shorten, do NOT skip anything
- skills: ALL skills found (technical + soft + tools + frameworks + methodologies), no limit
- experience.description: copy the FULL original text word by word, every bullet point, every responsibility, every achievement — do NOT shorten
- experience.technologies: list every technology/tool mentioned in that job
- projects: list every project with full description
- certifications: every certification, award, course mentioned
- rawKeywords: every meaningful word from the entire CV (skip only: and, the, a, an, of, in, to, for, with, on, at, by, is, are, was, were)
- If a field is missing use empty string "" or empty array []

Return JSON in this exact format:
{
  "basicInfo": { "name": "full name", "email": "email", "phone": "phone number", "location": "city/country", "linkedin": "url or empty", "github": "url or empty" },
  "summary": "full professional summary if exists, else empty string",
  "skills": [{ "name": "skill name", "confidence": 95 }],
  "experience": [{
    "title": "job title",
    "company": "company name",
    "duration": "time period",
    "location": "city or remote or empty",
    "description": "FULL original description — every single bullet point and responsibility, word for word",
    "technologies": ["tech1", "tech2"]
  }],
  "education": [{ "degree": "degree", "field": "field of study", "institution": "university name", "graduationYear": "year", "gpa": "gpa or empty" }],
  "projects": [{ "name": "project name", "description": "full description", "technologies": ["tech1"] }],
  "certifications": ["cert1", "cert2"],
  "languages": ["English", "Vietnamese"],
  "rawKeywords": ["every", "meaningful", "keyword", "from", "cv"]
}`;

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerous-direct-browser-access': 'true'
            },
            body: JSON.stringify({
                model: 'claude-haiku-4-5',
                max_tokens: 4000,
                messages: [{ role: 'user', content: prompt }]
            })
        });

        if (!response.ok) {
            throw new Error('Claude API error: ' + response.status);
        }

        const data = await response.json();
        let text = data.content[0].text.trim();
        // Strip markdown code blocks if present
        text = text.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();
        return JSON.parse(text);
    },

    // Chờ PDF.js load xong (tối đa 5 giây)
    waitForPdfJs(timeout = 5000) {
        return new Promise((resolve, reject) => {
            if (typeof pdfjsLib !== 'undefined') {
                return resolve();
            }
            const start = Date.now();
            const interval = setInterval(() => {
                if (typeof pdfjsLib !== 'undefined') {
                    clearInterval(interval);
                    resolve();
                } else if (Date.now() - start > timeout) {
                    clearInterval(interval);
                    reject(new Error('PDF.js không thể load. Vui lòng kiểm tra kết nối mạng và thử lại.'));
                }
            }, 100);
        });
    },

    async extractTextFromPDF(file) {
        await this.waitForPdfJs();

        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

        const pageTexts = [];

        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const textContent = await page.getTextContent();

            const textItems = textContent.items
                .map(item => item.str)
                .filter(Boolean);

            pageTexts.push(textItems.join(' '));
        }

        return pageTexts
            .join('\n')
            .replace(/[ \t]+/g, ' ')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    },

    tokenizeText(text) {
        if (!text) return [];

        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '') // remove accents
            .replace(/[^a-z0-9@.+#/\-\s]/g, ' ')
            .split(/\s+/)
            .map(t => t.trim())
            .filter(Boolean);
    },

    parseCVText(rawText, tokens = []) {
        const lines = rawText
            .split(/\r?\n/)
            .map(line => line.trim())
            .filter(Boolean);

        const lowerText = rawText.toLowerCase();

        const email = this.extractEmail(rawText);
        const phone = this.extractPhone(rawText);
        const name = this.extractName(lines, email, phone);
        const skills = this.extractSkills(tokens);
        const experience = this.extractExperience(lines, lowerText);
        const education = this.extractEducation(lines, lowerText);

        return {
            basicInfo: {
                name: name || '',
                email: email || '',
                phone: phone || ''
            },
            skills: skills.map(skill => ({
                name: skill,
                confidence: 92
            })),
            experience,
            education,
            rawText
        };
    },

    extractEmail(text) {
        const match = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
        return match ? match[0] : '';
    },

    extractPhone(text) {
        const match = text.match(/(\+?\d{1,3}[\s.-]?)?(\(?\d{2,4}\)?[\s.-]?)?[\d\s.-]{7,15}/);
        if (!match) return '';
        return match[0].replace(/\s+/g, ' ').trim();
    },

    extractName(lines, email, phone) {
        for (const line of lines.slice(0, 8)) {
            const clean = line.trim();

            if (!clean) continue;
            if (email && clean.includes(email)) continue;
            if (phone && clean.includes(phone)) continue;
            if (clean.length < 3 || clean.length > 60) continue;
            if (/\d/.test(clean)) continue;
            if (/@/.test(clean)) continue;

            // skip common section headers
            const lower = clean.toLowerCase();
            const blocked = [
                'curriculum vitae', 'cv', 'resume', 'profile', 'summary',
                'education', 'experience', 'skills', 'contact', 'objective'
            ];
            if (blocked.includes(lower)) continue;

            return clean;
        }
        return '';
    },

    extractSkills(tokens) {
        const skillDictionary = [
            'python', 'java', 'javascript', 'typescript', 'sql', 'mysql', 'postgresql',
            'excel', 'power bi', 'tableau', 'html', 'css', 'react', 'nodejs', 'node',
            'flask', 'fastapi', 'django', 'git', 'github', 'docker', 'aws', 'azure',
            'machine learning', 'deep learning', 'nlp', 'tensorflow', 'pytorch',
            'pandas', 'numpy', 'scikit-learn', 'data analysis', 'data analytics',
            'communication', 'teamwork', 'leadership', 'problem solving',
            'english', 'agile', 'scrum', 'figma', 'canva', 'word', 'powerpoint'
        ];

        const joined = tokens.join(' ');
        const found = [];

        for (const skill of skillDictionary) {
            if (skill.includes(' ')) {
                if (joined.includes(skill)) found.push(skill);
            } else {
                if (tokens.includes(skill)) found.push(skill);
            }
        }

        return [...new Set(found)].slice(0, 12);
    },

    extractExperience(lines, lowerText) {
        const expSection = this.extractSection(lines, [
            'experience', 'work experience', 'employment history',
            'kinh nghiệm', 'kinh nghiem'
        ], [
            'education', 'skills', 'projects', 'certifications',
            'học vấn', 'hoc van'
        ]);

        if (expSection.length === 0) {
            return [{
                title: '',
                company: '',
                duration: '',
                description: ''
            }];
        }

        const firstLine = expSection[0] || '';
        return [{
            title: firstLine,
            company: '',
            duration: '',
            description: expSection.slice(1, 4).join(' ')
        }];
    },

    extractEducation(lines, lowerText) {
        const eduSection = this.extractSection(lines, [
            'education', 'academic background', 'học vấn', 'hoc van'
        ], [
            'experience', 'skills', 'projects', 'certifications',
            'kinh nghiệm', 'kinh nghiem'
        ]);

        if (eduSection.length === 0) {
            return [{
                degree: '',
                field: '',
                institution: '',
                graduationYear: ''
            }];
        }

        const firstLine = eduSection[0] || '';
        const yearMatch = firstLine.match(/\b(19|20)\d{2}\b/);

        return [{
            degree: firstLine,
            field: '',
            institution: eduSection[1] || '',
            graduationYear: yearMatch ? yearMatch[0] : ''
        }];
    },

    extractSection(lines, startKeywords, endKeywords) {
        let startIndex = -1;

        for (let i = 0; i < lines.length; i++) {
            const lower = lines[i].toLowerCase();
            if (startKeywords.some(k => lower.includes(k))) {
                startIndex = i + 1;
                break;
            }
        }

        if (startIndex === -1) return [];

        const section = [];
        for (let i = startIndex; i < lines.length; i++) {
            const lower = lines[i].toLowerCase();
            if (endKeywords.some(k => lower.includes(k))) break;
            section.push(lines[i]);
        }

        return section.filter(Boolean).slice(0, 8);
    },

    async displayPDF(file, options = {}) {
        const {
            containerId = 'cvDocumentViewer',
            iframeId = 'pdfViewer',
            placeholderId = 'pdfPlaceholder',
            filenameDisplayId = 'cvFilenameDisplay'
        } = options;

        try {
            const validation = this.validateFile(file);
            if (!validation.isValid) {
                throw new Error(validation.errors[0]);
            }

            const container = document.getElementById(containerId);
            const iframe = document.getElementById(iframeId);
            const placeholder = document.getElementById(placeholderId);
            const filenameDisplay = document.getElementById(filenameDisplayId);

            if (!container || !iframe) {
                console.error('[PDFService] PDF viewer elements not found');
                return false;
            }

            this.cleanup();
            this.currentPDFUrl = URL.createObjectURL(file);

            if (placeholder) {
                placeholder.style.display = 'none';
            }

            iframe.src = this.currentPDFUrl;
            iframe.style.display = 'block';

            if (filenameDisplay) {
                filenameDisplay.textContent = file.name;
                filenameDisplay.title = file.name;
            }

            if (Config.DEBUG) {
                console.log('[PDFService] PDF displayed:', file.name);
            }

            return true;

        } catch (error) {
            console.error('[PDFService] Error displaying PDF:', error);
            return false;
        }
    },

    displayPDFFromUrl(url, filename = 'CV.pdf', options = {}) {
        const {
            iframeId = 'pdfViewer',
            placeholderId = 'pdfPlaceholder',
            filenameDisplayId = 'cvFilenameDisplay'
        } = options;

        try {
            const iframe = document.getElementById(iframeId);
            const placeholder = document.getElementById(placeholderId);
            const filenameDisplay = document.getElementById(filenameDisplayId);

            if (!iframe) {
                console.error('[PDFService] PDF iframe not found');
                return false;
            }

            if (placeholder) {
                placeholder.style.display = 'none';
            }

            iframe.src = url;
            iframe.style.display = 'block';

            if (filenameDisplay) {
                filenameDisplay.textContent = filename;
                filenameDisplay.title = filename;
            }

            return true;

        } catch (error) {
            console.error('[PDFService] Error displaying PDF from URL:', error);
            return false;
        }
    },

    hidePDF(options = {}) {
        const {
            iframeId = 'pdfViewer',
            placeholderId = 'pdfPlaceholder',
            filenameDisplayId = 'cvFilenameDisplay'
        } = options;

        const iframe = document.getElementById(iframeId);
        const placeholder = document.getElementById(placeholderId);
        const filenameDisplay = document.getElementById(filenameDisplayId);

        if (iframe) {
            iframe.style.display = 'none';
            iframe.src = '';
        }

        if (placeholder) {
            placeholder.style.display = 'block';
        }

        if (filenameDisplay) {
            filenameDisplay.textContent = '';
        }

        this.cleanup();
    },

    async saveCVToServer(parsedCVData) {
        try {
            const response = await fetch('http://localhost:5001/api/cv/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(parsedCVData)
            });
            const result = await response.json();
            if (result.success) {
                console.log('[PDFService] CV saved:', result.filename);
            }
        } catch (e) {
            console.warn('[PDFService] Could not save to server:', e.message);
        }
    },

    cleanup() {
        if (this.currentPDFUrl) {
            URL.revokeObjectURL(this.currentPDFUrl);
            this.currentPDFUrl = null;
        }
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = PDFService;
}