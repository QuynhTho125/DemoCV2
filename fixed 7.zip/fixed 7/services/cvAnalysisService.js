// ========================================
// CV Analysis Service
// Handles CV upload, extraction and analysis logic
// ========================================

const CVAnalysisService = {

    async uploadCV(file) {
        if (Config.DEBUG) console.log('[CVService] Uploading:', file.name);

        // Backend Stage 1 expects extracted text (frontend extracts via pdf.js).
        const rawText = await PDFService.extractTextFromPDF(file);

        const resp = await ApiService.post(Config.getApiUrl(Config.API.CV.UPLOAD), {
            text: rawText,
            filename: file.name
        });
        if (!resp?.success) {
            throw new Error(resp?.message || 'Upload CV failed');
        }

        // Stage 1 returns extracted JSON directly for Screen 2
        AppState.currentCVId = resp.cvId;
        AppState.parsedCVData = resp.data;
        AppState.fileInfo = {
            filename: resp.filename || file.name,
        };

        return resp;
    },

    async extractInfo(cvId) {
        if (Config.DEBUG) console.log('[CVService] Extracting info for:', cvId);

        if (AppState.currentCVId === cvId && AppState.parsedCVData) {
            return AppState.parsedCVData;
        }

        throw new Error('Chua co du lieu CV da trich xuat. Hay goi uploadCV truoc.');
    },

    async analyzeCV(cvId) {
        if (Config.DEBUG) console.log('[CVService] Analyzing:', cvId);

        try {
            // Stage 2 receives data from Screen2 inputs (user đã sửa).
            const formData = (typeof Screen2Component !== 'undefined' && Screen2Component.getFormData)
                ? Screen2Component.getFormData()
                : null;

            // Use full extracted JSON from Stage 1 (Claude) as baseline, then enrich with user edits.
            const parsed = AppState.parsedCVData || {};

            // Collect skills tags currently displayed on Screen2
            const skillsTags = Array.from(document.querySelectorAll('#screen2 .skills-container .tag'))
                .map(el => (el.textContent || '').trim())
                .filter(Boolean);

            const extractedSkills = (parsed.skills || []).map(s => (s?.name || s)).filter(Boolean);
            const experienceTexts = (parsed.experience || []).map(e => [
                e?.title, e?.company, e?.duration, e?.location, e?.description,
                Array.isArray(e?.technologies) ? e.technologies.join(' ') : ''
            ].filter(Boolean).join('\n')).filter(Boolean);
            const educationTexts = (parsed.education || []).map(e => [
                e?.degree, e?.field, e?.institution, e?.graduationYear, e?.gpa
            ].filter(Boolean).join(' ')).filter(Boolean);
            const projectTexts = (parsed.projects || []).map(p => [
                p?.name, p?.description,
                Array.isArray(p?.technologies) ? p.technologies.join(' ') : ''
            ].filter(Boolean).join('\n')).filter(Boolean);
            const certTexts = Array.isArray(parsed.certifications) ? parsed.certifications : [];
            const langTexts = Array.isArray(parsed.languages) ? parsed.languages : [];
            const keywordTexts = Array.isArray(parsed.rawKeywords) ? parsed.rawKeywords : [];

            const textParts = [
                // user edits (highest priority)
                formData?.basicInfo?.name,
                formData?.basicInfo?.email,
                formData?.basicInfo?.phone,
                formData?.experience,
                formData?.education,
                skillsTags.join(' ')
                ,
                // extracted baseline (to avoid "too little text" -> low score)
                parsed?.summary,
                extractedSkills.join(' '),
                experienceTexts.join('\n\n'),
                educationTexts.join('\n'),
                projectTexts.join('\n\n'),
                certTexts.join('\n'),
                langTexts.join(' '),
                keywordTexts.join(' ')
            ].filter(v => v !== undefined && v !== null && String(v).trim().length > 0);

            const payloadText = textParts.join('\n');

            const resp = await ApiService.post('http://127.0.0.1:8000/predict', { text: payloadText });
            if (!resp?.success) {
                throw new Error(resp?.error || resp?.message || 'Predict failed');
            }

            const data = resp.data || {};
            const explanation = data.explanation || {};
            const feedback = data.feedback || {};

            return {
                overallScore: data.match_percentage || 0,
                matchScore: data.match_percentage || 0,
                prediction: data.prediction,
                recommendation: data.result === 'Dat' ? 'Phù hợp để tiếp tục vòng sau' : 'Cần HR xem xét thêm',
                // Show human-friendly feedback to candidate (not SHAP factors)
                strengths: feedback.strengths || [],
                concerns: feedback.development_areas || [],
                explanation: explanation,
                reviewedByHR: false,
                analysisId: resp.analysisId,
                debug: data.debug || {}
            };
        } catch (e) {
            console.error('[CVService] XGBoost predict failed:', e);
            throw e;
        }
    },

    /**
     * Build feature vector (721 dims) tu raw CV text + parsed data
     * Khop voi feature_names_full.pkl:
     *   [0..668] = keyword bag-of-words
     *   [669..719] = Job Roles one-hot (51 roles)
     *   [720] = Age_Scaled
     */
    buildFeatureVector(parsedCV, rawText, featureNames) {
        // 1. Tokenize raw text
        const tokens = new Set(
            (rawText || '')
                .toLowerCase()
                .replace(/[^a-z0-9\s]/g, ' ')
                .split(/\s+/)
                .filter(t => t.length > 1)
        );

        // 2. Job role detection
        const allText = (rawText || '').toLowerCase();
        const jobTitles = (parsedCV.experience || []).map(e => (e.title || '').toLowerCase());

        const JOB_ROLE_MAP = {
            'Job Roles_AI Researcher': ['ai researcher'],
            'Job Roles_AI Specialist': ['ai specialist'],
            'Job Roles_Accountant': ['accountant', 'accounting'],
            'Job Roles_Architect': ['architect'],
            'Job Roles_Biomedical Engineer': ['biomedical engineer'],
            'Job Roles_Business Analyst': ['business analyst'],
            'Job Roles_Chef': ['chef', 'cook'],
            'Job Roles_Civil Engineer': ['civil engineer'],
            'Job Roles_Cloud Architect': ['cloud architect'],
            'Job Roles_Construction Manager': ['construction manager'],
            'Job Roles_Content Writer': ['content writer', 'copywriter'],
            'Job Roles_Creative Director': ['creative director'],
            'Job Roles_Customer Service Representative': ['customer service'],
            'Job Roles_Cybersecurity Analyst': ['cybersecurity', 'security analyst'],
            'Job Roles_Data Analyst': ['data analyst'],
            'Job Roles_Database Administrator': ['database administrator', 'dba'],
            'Job Roles_Dentist': ['dentist'],
            'Job Roles_Electrician': ['electrician'],
            'Job Roles_Environmental Scientist': ['environmental scientist'],
            'Job Roles_Event Planner': ['event planner'],
            'Job Roles_Financial Analyst': ['financial analyst'],
            'Job Roles_Fitness Coach': ['fitness coach'],
            'Job Roles_Graphic Designer': ['graphic designer'],
            'Job Roles_HR Specialist': ['hr specialist', 'human resources'],
            'Job Roles_Journalist': ['journalist', 'reporter'],
            'Job Roles_Lawyer': ['lawyer', 'attorney'],
            'Job Roles_Legal Consultant': ['legal consultant'],
            'Job Roles_Machine Learning Engineer': ['machine learning engineer', 'ml engineer'],
            'Job Roles_Marketing Manager': ['marketing manager'],
            'Job Roles_Mechanical Engineer': ['mechanical engineer'],
            'Job Roles_Nurse': ['nurse', 'nursing'],
            'Job Roles_Operations Manager': ['operations manager'],
            'Job Roles_Personal Trainer': ['personal trainer'],
            'Job Roles_Pharmacist': ['pharmacist'],
            'Job Roles_Physician': ['physician', 'doctor'],
            'Job Roles_Pilot': ['pilot', 'aviation'],
            'Job Roles_Product Manager': ['product manager'],
            'Job Roles_Psychologist': ['psychologist'],
            'Job Roles_Research Scientist': ['research scientist'],
            'Job Roles_Robotics Engineer': ['robotics engineer'],
            'Job Roles_SEO Specialist': ['seo specialist', 'seo'],
            'Job Roles_Sales Representative': ['sales representative', 'sales rep'],
            'Job Roles_Social Worker': ['social worker'],
            'Job Roles_Software Engineer': ['software engineer', 'software developer', 'developer'],
            'Job Roles_Supply Chain Manager': ['supply chain'],
            'Job Roles_Systems Analyst': ['systems analyst'],
            'Job Roles_Teacher': ['teacher', 'instructor', 'lecturer'],
            'Job Roles_UX Designer': ['ux designer', 'ui designer'],
            'Job Roles_Urban Planner': ['urban planner'],
            'Job Roles_Veterinarian': ['veterinarian', 'vet'],
            'Job Roles_Web Developer': ['web developer', 'frontend developer', 'backend developer'],
        };

        // 3. Uoc tinh tuoi
        const ageMatch = (rawText || '').match(/\b(19[6-9]\d|200[0-9])\b/);
        let ageScaled = 0.22; // default ~28 tuoi
        if (ageMatch) {
            const birthYear = parseInt(ageMatch[1]);
            const age = new Date().getFullYear() - birthYear;
            ageScaled = Math.max(0, Math.min(1, (age - 18) / (65 - 18)));
        }

        // 4. Map theo featureNames
        return featureNames.map(fname => {
            if (fname === 'Age_Scaled') return ageScaled;
            if (fname.startsWith('Job Roles_')) {
                const kws = JOB_ROLE_MAP[fname] || [];
                return kws.some(kw => allText.includes(kw) || jobTitles.some(t => t.includes(kw))) ? 1 : 0;
            }
            return tokens.has(fname.toLowerCase()) ? 1 : 0;
        });
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = CVAnalysisService;
}

// Patch: them getResult va getExplanation bi thieu
const _CVAnalysisServicePatch = {
    async getResult(analysisId) {
        if (Config.DEBUG) console.log('[CVService] Getting result for:', analysisId);

        const resp = await ApiService.get(`http://127.0.0.1:8000/analysis/${analysisId}`);
        if (!resp?.success) {
            throw new Error(resp?.message || resp?.error || 'Không lấy được result từ API2');
        }

        const d = resp.data || {};
        const explanation = d.explanation || {};

        return {
            status: (d.match_percentage || 0) >= 75 ? 'matched' : 'reviewed',
            matchScore: d.match_percentage || 0,
            message: d.result || '',
            strengths: explanation.top_positives || [],
            developmentAreas: explanation.top_negatives || [],
            explanation: explanation,
            reviewedByHR: false
        };
    },

    async getExplanation(analysisId) {
        if (Config.DEBUG) console.log('[CVService] Getting explanation for:', analysisId);

        const resp = await ApiService.get(`http://127.0.0.1:8000/analysis/${analysisId}/explain`);
        if (!resp?.success) {
            throw new Error(resp?.message || resp?.error || 'Không lấy được explanation từ API2');
        }

        return { explanation: resp.explanation || resp.data?.explanation || {} };
    }
};

Object.assign(CVAnalysisService, _CVAnalysisServicePatch);
