// ========================================
// Database Abstraction Layer
// Connects UI to Backend API or Mock Data
// ========================================

const Database = {
    // ========================================
    // SURVEY OPERATIONS
    // ========================================

    /**
     * Get survey questions (Fixed UI content)
     * @returns {Promise<Array>} Survey questions
     */
    async getSurveyQuestions() {
        if (Config.USE_MOCK_DATA) {
            return Promise.resolve(SurveyQuestions);
        }
        // In real app, might still fetch from backend or keep fixed
        return Promise.resolve(SurveyQuestions);
    },

    /**
     * Submit survey responses to backend
     * @param {Object} responses - Survey responses
     * @returns {Promise<Object>} Submission confirmation
     */
    /**
     * Submit survey responses to backend
     * @param {Object} responses - Survey responses
     * @returns {Promise<Object>} Submission confirmation
     */
    async submitSurvey(responses) {
        // 1. Submit to Google Sheets (if configured)
        // Note: We attempt this even in Mock Mode if URL is present, as per user request
        if (Config.API.SURVEY.GOOGLE_SHEET_URL) {
            try {
                // Use no-cors mode for Google Apps Script Web App
                await fetch(Config.API.SURVEY.GOOGLE_SHEET_URL, {
                    method: 'POST',
                    mode: 'no-cors',
                    cache: 'no-cache',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    redirect: 'follow',
                    body: JSON.stringify(responses) // Send flat object
                });
                console.log('[Database] Sent to Google Sheet');
            } catch (err) {
                console.error('[Database] Failed to send to Google Sheet:', err);
                // Don't block success flow
            }
        }

        if (Config.USE_MOCK_DATA) {
            console.log('[Database-Mock] Survey submitted:', responses);
            return Promise.resolve({
                success: true,
                message: 'Cảm ơn bạn đã gửi phản hồi (Demo Mode)!',
                submittedAt: new Date().toISOString()
            });
        }

        return await ApiService.post(Config.getApiUrl(Config.API.SURVEY.SUBMIT), responses);
    },

    // ========================================
    // PROCESSING STEPS (Fixed UI content)
    // ========================================

    /**
     * Get processing steps for Screen 3
     * @returns {Promise<Array>} Processing steps
     */
    async getProcessingSteps() {
        return Promise.resolve(ProcessingSteps);
    },

    // ========================================
    // CV OPERATIONS - Connect to Backend
    // ========================================

    /**
     * Upload CV file to backend
     * @param {File} file - CV file to upload
     * @returns {Promise<Object>} Upload result
     */
    async uploadCV(file) {
        if (Config.USE_MOCK_DATA) {
            console.log('[Database-Mock] Uploading CV:', file?.name);
            await this._delay(1500); // Simulate upload delay
            return Promise.resolve({
                cvId: 'CV-DEMO-' + Date.now(),
                filename: file?.name,
                uploadedAt: new Date().toISOString()
            });
        }

        const formData = new FormData();
        formData.append('file', file);
        return await ApiService.upload(Config.getApiUrl(Config.API.CV.UPLOAD), formData);
    },

    /**
     * Get extracted CV data from backend ML
     * @param {string} cvId 
     * @returns {Promise<Object>} Extracted CV data from ML
     */
    async getCVExtracted(cvId) {
        if (Config.USE_MOCK_DATA) {
            console.log('[Database-Mock] Getting extracted data for:', cvId);
            return Promise.resolve(MockCVData);
        }

        return await ApiService.get(Config.getApiUrl(Config.API.CV.EXTRACT, { id: cvId }));
    },

    // ========================================
    // ANALYSIS OPERATIONS - Connect to Backend ML
    // ========================================

    /**
     * Get analysis result from backend ML
     * @param {string} analysisId 
     * @returns {Promise<Object>} Analysis result from ML
     */
    async getAnalysisResult(analysisId) {
        if (Config.USE_MOCK_DATA) {
            console.log('[Database-Mock] Getting analysis result for:', analysisId);
            return Promise.resolve(MockAnalysisResult);
        }

        return await ApiService.get(Config.getApiUrl(Config.API.ANALYSIS.RESULT, { id: analysisId }));
    },

    // ========================================
    // UTILITY METHODS
    // ========================================

    /**
     * Simulate delay
     * @param {number} ms - Milliseconds to delay
     */
    _delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Database;
}
