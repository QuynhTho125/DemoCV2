from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os
import joblib
import numpy as np
from datetime import datetime
import ssl
import urllib.error
import urllib.request

app = Flask(__name__)
CORS(app)

OUTPUT_DIR = 'output'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ========================================
# LOAD XGBOOST MODEL + FEATURE NAMES
# (tu backend.py + Modelxgb.py)
# ========================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    model = joblib.load(os.path.join(BASE_DIR, 'xgb_model.pkl'))
    feature_names = joblib.load(os.path.join(BASE_DIR, 'feature_names_full.pkl'))
    tfidf = joblib.load(os.path.join(BASE_DIR, 'tfidf_vectorizer.pkl'))
    print(f'[Server] XGBoost model loaded! Features: {len(feature_names)}')
    print(f'[Server] TF-IDF vectorizer loaded!')
except Exception as e:
    model = None
    feature_names = []
    tfidf = None
    print(f'[Server] WARNING: Could not load model: {e}')

# Feature categories
TEXT_FEATURES = [f for f in feature_names if not f.startswith('Gender_')
                 and not f.startswith('Race_')
                 and not f.startswith('Job Roles_')
                 and f != 'Age_Scaled']
GENDER_FEATURES = [f for f in feature_names if f.startswith('Gender_')]
RACE_FEATURES = [f for f in feature_names if f.startswith('Race_')]
JOB_FEATURES = [f for f in feature_names if f.startswith('Job Roles_')]


# ========================================
# ROUTE: Luu CV JSON (tu server.py cu)
# ========================================
@app.route('/api/cv/save', methods=['POST'])
def save_cv():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data'}), 400

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        name = data.get('basicInfo', {}).get('name', 'unknown').replace(' ', '_')
        filename = f'cv_{name}_{timestamp}.json'
        filepath = os.path.join(OUTPUT_DIR, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        print(f'[Server] Saved CV: {filepath}')
        return jsonify({'success': True, 'filename': filename})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ========================================
# ROUTE: Du doan bang XGBoost
# (tu backend.py - POST /predict)
# ========================================
@app.route('/api/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({
            'success': False,
            'message': 'Model chua duoc load. Kiem tra xgb_model.pkl va feature_names_full.pkl.'
        }), 500

    try:
        data = request.get_json()
        if not data or 'features' not in data:
            return jsonify({'success': False, 'message': 'Thieu truong features'}), 400

        input_data = np.array(data['features'], dtype=float).reshape(1, -1)

        if input_data.shape[1] != len(feature_names):
            return jsonify({
                'success': False,
                'message': f'So features khong khop: gui {input_data.shape[1]}, model can {len(feature_names)}'
            }), 400

        prediction = model.predict(input_data)[0]
        probability = model.predict_proba(input_data)[0].tolist()
        score = round(probability[1] * 100, 1)

        print(f'[Server] Predict: result={int(prediction)}, score={score}%')

        return jsonify({
            'success': True,
            'prediction': int(prediction),   # 1 = Dau, 0 = Rot
            'probability': probability,
            'score': score,                   # % phu hop (0-100)
            'message': 'Phan tich boi XGBoost thanh cong!'
        })

    except Exception as e:
        print(f'[Server] Predict error: {e}')
        return jsonify({'success': False, 'message': str(e)}), 500


# ========================================
# ROUTE: Lay danh sach feature names
# ========================================
@app.route('/api/features', methods=['GET'])
def get_features():
    return jsonify({
        'success': True,
        'features': list(feature_names),
        'count': len(feature_names)
    })


# ========================================
# ROUTE: CV Upload (placeholder cho production)
# ========================================
@app.route('/api/cv/upload', methods=['POST'])
def upload_cv():
    try:
        # Stage 1 in demo: Frontend extracts PDF text using pdf.js,
        # then sends JSON { text, filename } to this endpoint.
        if not request.is_json:
            return jsonify({
                'success': False,
                'message': 'Stage1 expects JSON body: { "text": "...", "filename": "..." }'
            }), 400

        payload = request.get_json(silent=True) or {}
        text_cv = (payload.get('text') or payload.get('text_cv') or '').strip()
        filename = payload.get('filename') or 'cv.pdf'

        if not text_cv:
            return jsonify({'success': False, 'message': 'Thieu truong text trong body JSON'}), 400

        # 2) Call Claude to extract ALL meaningful fields
        api_key = os.environ.get('ANTHROPIC_API_KEY')
        if not api_key:
            # Demo fallback: lấy key như bên frontend đang dùng (để khỏi tịt khi bạn chưa set env).
            # Lưu ý: key này nên chuyển sang env trong production.
            api_key = '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\n'
        api_key = str(api_key).strip()

        prompt = f"""You are a CV content extractor. Extract ALL meaningful content from the CV below and return ONLY valid JSON, NO markdown, NO backticks, NO explanation.

CV TEXT:
{text_cv}

Rules:
- Extract EVERYTHING meaningful — do NOT summarize, do NOT shorten, do NOT skip anything
- skills: ALL skills found (technical + soft + tools + frameworks + methodologies), no limit
- experience.description: copy the FULL original text word by word, every bullet point, every responsibility, every achievement — do NOT shorten
- experience.technologies: list every technology/tool mentioned in that job
- projects: list every project with full description
- certifications: every certification, award, course mentioned
- rawKeywords: every meaningful word from the entire CV (skip only: and, the, a, an, of, in, to, for, with, on, at, by, is, are, was, were)
- If a field is missing use empty string "" or empty array []

Return JSON in this exact format:
{{
  "basicInfo": {{
    "name": "full name", "email": "email", "phone": "phone number", "location": "city/country", "linkedin": "url or empty", "github": "url or empty"
  }},
  "summary": "full professional summary if exists, else empty string",
  "skills": [{{"name": "skill name", "confidence": 95}}],
  "experience": [{{
    "title": "job title",
    "company": "company name",
    "duration": "time period",
    "location": "city or remote or empty",
    "description": "FULL original description — every single bullet point and responsibility, word for word",
    "technologies": ["tech1", "tech2"]
  }}],
  "education": [{{
    "degree": "degree", "field": "field of study", "institution": "university name", "graduationYear": "year", "gpa": "gpa or empty"
  }}],
  "projects": [{{"name": "project name", "description": "full description", "technologies": ["tech1"]}}],
  "certifications": ["cert1", "cert2"],
  "languages": ["English", "Vietnamese"],
  "rawKeywords": ["every", "meaningful", "keyword", "from", "cv"]
}}"""

        body = json.dumps({
            'model': 'claude-haiku-4-5',
            'max_tokens': 8000,
            'messages': [{'role': 'user', 'content': prompt}],
        }).encode('utf-8')

        headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
            'anthropic-dangerous-direct-browser-access': 'true',
        }

        req = urllib.request.Request(
            url='https://api.anthropic.com/v1/messages',
            data=body,
            headers=headers,
            method='POST'
        )

        try:
            with urllib.request.urlopen(req, timeout=180, context=ssl.create_default_context()) as r:
                raw = r.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            raw = e.read().decode('utf-8', errors='ignore') if hasattr(e, 'read') else ''
            return jsonify({'success': False, 'message': 'Claude API error', 'details': raw}), 500

        data = json.loads(raw)
        text = (data.get('content') or [{}])[0].get('text', '').strip()
        if not text:
            return jsonify({'success': False, 'message': 'Claude trả về rỗng'}), 500

        # Strip code fences if present
        text = text.replace('```json', '').replace('```', '').strip()
        parsed = json.loads(text)

        # 3) Save JSON to disk
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        name = (parsed.get('basicInfo') or {}).get('name', 'unknown').replace(' ', '_')
        cv_id = f'cv_{name}_{timestamp}'
        filepath = os.path.join(OUTPUT_DIR, f'{cv_id}.json')
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(parsed, f, ensure_ascii=False, indent=2)

        return jsonify({
            'success': True,
            'cvId': cv_id,
            'data': parsed,
            'filename': os.path.basename(filepath),
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ========================================
# ROUTE: Analysis Result
# ========================================
@app.route('/api/analysis/<analysis_id>', methods=['GET'])
def get_analysis(analysis_id):
    return jsonify({
        'success': True,
        'analysisId': analysis_id,
        'status': 'completed',
        'message': 'Ket qua da duoc luu trong AppState'
    })


# ========================================
# ROUTE: Tien xu ly CV text -> feature vector TF-IDF
# ========================================
@app.route('/api/preprocess', methods=['POST'])
def preprocess():
    if tfidf is None:
        return jsonify({'success': False, 'message': 'TF-IDF chua duoc load'}), 500

    try:
        data = request.get_json()
        raw_text = data.get('text', '')
        job_role = data.get('jobRole', '')
        gender = data.get('gender', '')
        race = data.get('race', '')
        age = data.get('age', 28)

        # 1. TF-IDF cho phan text
        X_text = tfidf.transform([raw_text.lower()]).toarray()[0]

        # 2. Gender one-hot
        X_gender = [1 if f == f'Gender_{gender}' else 0 for f in GENDER_FEATURES]

        # 3. Race one-hot
        X_race = [1 if f == f'Race_{race}' else 0 for f in RACE_FEATURES]

        # 4. Job Role one-hot
        X_job = [1 if f == f'Job Roles_{job_role}' else 0 for f in JOB_FEATURES]

        # 5. Age scaled (18-65)
        age_scaled = max(0.0, min(1.0, (float(age) - 18) / (65 - 18)))

        # 6. Ghep lai theo dung thu tu feature_names
        features = list(X_text) + X_gender + X_race + X_job + [age_scaled]

        nonzero = sum(1 for v in features if v != 0)
        print(f'[Server] Preprocess: {len(features)} features, {nonzero} non-zero')

        return jsonify({
            'success': True,
            'features': features,
            'feature_count': len(features),
            'nonzero_count': nonzero
        })

    except Exception as e:
        print(f'[Server] Preprocess error: {e}')
        return jsonify({'success': False, 'message': str(e)}), 500


if __name__ == '__main__':
    print('=' * 50)
    print('CV Analysis Server - http://localhost:5001')
    print('=' * 50)
    print('Routes:')
    print('  POST /api/cv/save        - Luu CV JSON')
    print('  POST /api/cv/upload      - Nhan CV upload')
    print('  POST /api/predict        - Du doan XGBoost')
    print('  GET  /api/features       - Lay feature names')
    print('  GET  /api/analysis/<id>  - Lay ket qua phan tich')
    print('=' * 50)
    app.run(port=5001, debug=False)
