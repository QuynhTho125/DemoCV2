from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import numpy as np
import shap
import time
from typing import Any, Dict, Optional

app = FastAPI()

# 1. CẤU HÌNH CHO PHÉP REACT GỌI ĐẾN
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. LOAD VŨ KHÍ (Load 1 lần duy nhất trong try-except)
print("[*] Starting UniBridge AI system...")
try:
    # Nhớ để đúng tên file pkl của ông trong thư mục nha
    model = joblib.load('xgb_model.pkl')
    feature_names = joblib.load('feature_names_fair.pkl')
    tfidf = joblib.load('tfidf_vectorizer.pkl')

    # Khởi tạo explainer SAU KHI load xong model
    explainer = shap.TreeExplainer(model)

    print(f"--- Success! Ready with {len(feature_names)} features. ---")
except Exception as e:
    print(f"--- FATAL: Could not load pkl files! ({e}) ---")

# In-memory store for analysis results (demo-friendly)
ANALYSIS_STORE: Dict[str, Dict[str, Any]] = {}


# --- HÀM BỔ TRỢ GIẢI THÍCH SHAP ---
def get_shap_explanation(input_data_dense):
    # input_data_dense phải là dạng array (không phải sparse)
    shap_values = explainer(input_data_dense)
    shap_values.feature_names = feature_names
    sv = shap_values[0]

    impacts = []
    for i in range(len(feature_names)):
        # Chỉ lấy những cái có ảnh hưởng (impact khác 0) để JSON nó nhẹ
        if sv.values[i] != 0:
            impacts.append({
                "feature": feature_names[i],
                "impact": float(sv.values[i])
            })

    # Sắp xếp lấy Top 3 điểm cộng và Top 3 điểm trừ
    positives = sorted([x for x in impacts if x['impact'] > 0], key=lambda x: x['impact'], reverse=True)[:3]
    negatives = sorted([x for x in impacts if x['impact'] < 0], key=lambda x: x['impact'])[:3]

    return {
        "base_score": round(float(sv.base_values), 2),
        "top_positives": positives,
        "top_negatives": negatives
    }

def build_human_feedback(text: str, match_percentage: float, shap_explanation: Optional[Dict[str, Any]] = None):
    """
    Return user-friendly feedback (VN) based on CV text + SHAP.
    - Candidate-facing: strengths/development_areas as readable sentences
    - Technical SHAP remains in `explanation` for internal explainability
    """
    t = (text or "").strip()
    low = t.lower()
    shap_explanation = shap_explanation or {}

    def _is_noise_feature(fname: str) -> bool:
        if not fname:
            return True
        if fname == "Age_Scaled":
            return True
        if fname.startswith("Gender_") or fname.startswith("Race_"):
            return True
        if fname.startswith("Job Roles_"):
            return True
        return False

    def _pretty_feature(fname: str) -> str:
        # Most are plain keywords; keep as-is but readable
        return str(fname).replace("_", " ").strip()

    top_pos = [x for x in (shap_explanation.get("top_positives") or []) if isinstance(x, dict)]
    top_neg = [x for x in (shap_explanation.get("top_negatives") or []) if isinstance(x, dict)]
    top_pos = [x for x in top_pos if not _is_noise_feature(str(x.get("feature", "")))]
    top_neg = [x for x in top_neg if not _is_noise_feature(str(x.get("feature", "")))]

    strengths: list[str] = []
    dev: list[str] = []

    # 1) Score overview (candidate-readable)
    if match_percentage >= 80:
        strengths.append(
            "Tổng quan: Mức độ phù hợp với JD đang ở mức cao. CV của bạn đã thể hiện khá rõ năng lực và mức độ liên quan tới vị trí."
        )
        dev.append(
            "Gợi ý nâng cấp: Chọn 2–3 thành tựu mạnh nhất và đưa lên phần đầu (Summary/Highlights) để HR nắm được giá trị của bạn trong 10 giây."
        )
    elif match_percentage >= 60:
        strengths.append(
            "Tổng quan: Mức độ phù hợp ở mức khá. Bạn có nền tảng phù hợp, nhưng cần làm nổi bật hơn các yếu tố liên quan trực tiếp tới JD."
        )
        dev.append(
            "Gợi ý cải thiện: Viết lại bullet theo hướng “Action + Tool/Method + Result (số liệu)” để tăng sức thuyết phục và giúp HR đánh giá nhanh."
        )
    else:
        dev.append(
            "Tổng quan: Mức độ phù hợp đang thấp. Khả năng cao CV hiện chưa nhấn mạnh đúng từ khóa/kỹ năng trọng tâm mà JD cần."
        )
        dev.append(
            "Gợi ý ưu tiên: Tùy biến CV theo JD (đưa các keyword quan trọng vào Skills + Experience + Projects), tránh để keyword chỉ xuất hiện 1 lần."
        )

    # 2) Completeness / structure signals
    has_email = ("@" in low) and ("." in low)
    has_phone = any(ch.isdigit() for ch in low) and ("+" in low or "0" in low)
    if has_email:
        strengths.append("Thông tin liên hệ: Có email rõ ràng, giúp HR liên hệ nhanh.")
    else:
        dev.append("Thông tin liên hệ: Bổ sung email ở phần đầu CV để HR dễ thấy ngay.")
    if has_phone:
        strengths.append("Thông tin liên hệ: Có số điện thoại, hồ sơ đầy đủ hơn.")
    else:
        dev.append("Thông tin liên hệ: Bổ sung số điện thoại (định dạng gọn, nhất quán).")

    has_exp = ("experience" in low) or ("kinh nghiệm" in low) or ("work experience" in low)
    has_proj = ("project" in low) or ("dự án" in low) or ("portfolio" in low)
    has_skill = ("skill" in low) or ("kỹ năng" in low)
    if has_exp:
        strengths.append("Cấu trúc: Có mục Kinh nghiệm/Work Experience, dễ đối chiếu với JD.")
    else:
        dev.append("Cấu trúc: Thêm mục Kinh nghiệm. Mỗi mục nên có: vai trò, phạm vi, công nghệ, và kết quả/impact.")
    if has_proj:
        strengths.append("Nội dung: Có dự án/portfolio, giúp chứng minh năng lực thực tế.")
    else:
        dev.append("Nội dung: Thêm 1–3 dự án tiêu biểu (mục tiêu, vai trò, tech stack, kết quả định lượng).")
    if has_skill:
        strengths.append("Kỹ năng: Có mục kỹ năng. Nên nhóm theo Tech/Tools/Soft skills để đọc nhanh hơn.")
    else:
        dev.append("Kỹ năng: Thêm mục kỹ năng (công cụ/framework + kỹ năng mềm liên quan trực tiếp tới vị trí).")

    # 3) Turn SHAP into candidate-friendly insights
    if top_pos:
        pos_names = [_pretty_feature(x.get("feature", "")) for x in top_pos[:5] if x.get("feature")]
        if pos_names:
            strengths.append(
                "Điểm nổi bật theo nội dung CV: CV đang nhấn mạnh tốt các yếu tố như "
                + ", ".join(pos_names)
                + ". Hãy đảm bảo các yếu tố này xuất hiện trong cả Skills và Experience/Projects."
            )
            strengths.append(
                "Gợi ý trình bày: Với mỗi kỹ năng/keyword mạnh, thêm 1–2 bullet nêu rõ bạn đã dùng nó để làm gì và tạo ra kết quả gì."
            )

    if top_neg:
        neg_names = [_pretty_feature(x.get("feature", "")) for x in top_neg[:5] if x.get("feature")]
        if neg_names:
            dev.append(
                "Điểm cần bổ sung theo nội dung CV: Mô hình chưa thấy (hoặc thấy ít) các yếu tố như "
                + ", ".join(neg_names)
                + ". Nếu bạn có trải nghiệm liên quan, hãy đưa vào Skills/Experience (tránh chỉ nhắc thoáng qua)."
            )
            dev.append(
                "Gợi ý tối ưu ATS: Đặt keyword đúng ngữ cảnh (ví dụ: 'Xây dashboard bằng Power BI', 'Triển khai model bằng FastAPI') thay vì chỉ liệt kê tên."
            )

    # 4) Add a few universal high-signal suggestions (longer but still useful)
    dev.append("Tăng độ tin cậy: Ưu tiên số liệu (time saved, revenue, accuracy, latency, users, scale) thay vì mô tả chung chung.")
    dev.append("Rõ ràng vai trò: Với dự án nhóm, ghi rõ bạn chịu trách nhiệm phần nào (ownership) và bạn đã tác động ra sao.")
    dev.append("Tối ưu 1 trang: Nếu CV dài, đưa Highlights lên đầu và cắt bớt phần ít liên quan tới JD.")

    # Deduplicate while preserving order
    def _dedupe(items: list[str]) -> list[str]:
        seen = set()
        out = []
        for s in items:
            key = s.strip()
            if not key or key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out

    strengths = _dedupe(strengths)[:5]
    dev = _dedupe(dev)[:5]

    return {"strengths": strengths, "development_areas": dev}


# --- CÁC ĐƯỜNG DẪN (ROUTES) ---

@app.get("/")
async def root():
    return {"message": "API UniBridge is running! Go to /docs to test."}


class PredictRequest(BaseModel):
    # Stage 2 receives the text built from Screen2 form fields.
    text: str
    gender: Optional[str] = None
    race: Optional[str] = None
    jobRole: Optional[str] = None
    age: Optional[float] = None


@app.post("/predict")
async def predict_cv(payload: PredictRequest):
    try:
        # 1. TF-IDF từ text người dùng đã sửa
        text_cv = payload.text or ""
        input_data_sparse = tfidf.transform([text_cv.lower()])
        input_data_dense = input_data_sparse.toarray()

        # 2. Build đủ 721 features (đúng thứ tự theo feature_names đã train)
        #    training: [text TF-IDF] + [Gender_*] + [Race_*] + [Job Roles_*] + [Age_Scaled]
        expected_size = len(feature_names)
        current_size = input_data_dense.shape[1]

        input_data_ready = np.zeros((1, expected_size))
        input_data_ready[0, :min(current_size, expected_size)] = input_data_dense[0, :min(current_size, expected_size)]

        # Fill Job Roles_* one-hot từ keywords trong text
        JOB_ROLE_MAP = {
            'Job Roles_AI Researcher': ['ai researcher'],
            'Job Roles_AI Specialist': ['ai specialist'],
            'Job Roles_Accountant': ['accountant', 'accounting'],
            'Job Roles_Architect': ['architect'],
            'Job Roles_Biomedical Engineer': ['biomedical engineer'],
            'Job Roles_Business Analyst': ['business analyst'],
            'Job Roles_Chef': ['chef', 'cook'],
            'Job Roles_Civil Engineer': ['civil engineer'],
            'Job Roles_Cloud Architect': ['cloud architect'],
            'Job Roles_Construction Manager': ['construction manager'],
            'Job Roles_Content Writer': ['content writer', 'copywriter'],
            'Job Roles_Creative Director': ['creative director'],
            'Job Roles_Customer Service Representative': ['customer service'],
            'Job Roles_Cybersecurity Analyst': ['cybersecurity', 'security analyst'],
            'Job Roles_Data Analyst': ['data analyst'],
            'Job Roles_Database Administrator': ['database administrator', 'dba'],
            'Job Roles_Dentist': ['dentist'],
            'Job Roles_Electrician': ['electrician'],
            'Job Roles_Environmental Scientist': ['environmental scientist'],
            'Job Roles_Event Planner': ['event planner'],
            'Job Roles_Financial Analyst': ['financial analyst'],
            'Job Roles_Fitness Coach': ['fitness coach'],
            'Job Roles_Graphic Designer': ['graphic designer'],
            'Job Roles_HR Specialist': ['hr specialist', 'human resources'],
            'Job Roles_Journalist': ['journalist', 'reporter'],
            'Job Roles_Lawyer': ['lawyer', 'attorney'],
            'Job Roles_Legal Consultant': ['legal consultant'],
            'Job Roles_Machine Learning Engineer': ['machine learning engineer', 'ml engineer'],
            'Job Roles_Marketing Manager': ['marketing manager'],
            'Job Roles_Mechanical Engineer': ['mechanical engineer'],
            'Job Roles_Nurse': ['nurse', 'nursing'],
            'Job Roles_Operations Manager': ['operations manager'],
            'Job Roles_Personal Trainer': ['fitness coach', 'personal trainer'],
            'Job Roles_Pharmacist': ['pharmacist'],
            'Job Roles_Physician': ['physician', 'doctor'],
            'Job Roles_Pilot': ['pilot', 'aviation'],
            'Job Roles_Product Manager': ['product manager'],
            'Job Roles_Psychologist': ['psychologist'],
            'Job Roles_Research Scientist': ['research scientist'],
            'Job Roles_Robotics Engineer': ['robotics engineer'],
            'Job Roles_SEO Specialist': ['seo specialist', 'seo'],
            'Job Roles_Sales Representative': ['sales representative', 'sales rep'],
            'Job Roles_Social Worker': ['social worker'],
            'Job Roles_Software Engineer': ['software engineer', 'software developer', 'developer'],
            'Job Roles_Supply Chain Manager': ['supply chain'],
            'Job Roles_Systems Analyst': ['systems analyst'],
            'Job Roles_Teacher': ['teacher', 'instructor', 'lecturer'],
            'Job Roles_UX Designer': ['ux designer', 'ui designer'],
            'Job Roles_Urban Planner': ['urban planner'],
            'Job Roles_Veterinarian': ['veterinarian', 'vet'],
            'Job Roles_Web Developer': ['web developer', 'frontend developer', 'backend developer'],
        }

        lower_text = (text_cv or '').lower()
        for i, fname in enumerate(feature_names):
            if not fname.startswith('Job Roles_'):
                continue
            kws = JOB_ROLE_MAP.get(fname, [])
            input_data_ready[0, i] = 1.0 if any(kw in lower_text for kw in kws) else 0.0

        # Fill Age_Scaled
        age_scaled = 0.22  # default ~28 tuoi
        import re
        m = re.search(r"\b(19[6-9]\d|200[0-9])\b", lower_text)
        if m:
            birth_year = int(m.group(1))
            age = int(time.strftime("%Y")) - birth_year
            age_scaled = max(0.0, min(1.0, (age - 18) / (65 - 18)))

        for i, fname in enumerate(feature_names):
            if fname == 'Age_Scaled':
                input_data_ready[0, i] = float(age_scaled)

        nonzero = int(np.count_nonzero(input_data_ready))
        print(f"[*] Build features: tfidf_dim={current_size}, final_dim={input_data_ready.shape[1]}, nonzero={nonzero}")

        # 3. DỰ ĐOÁN
        prediction = int(model.predict(input_data_ready)[0])
        probability = model.predict_proba(input_data_ready)[0].tolist()
        match_percentage = round(probability[1] * 100, 1)  # numeric (0-100)

        # 4. SHAP giải thích
        explanation = get_shap_explanation(input_data_ready)

        analysis_id = f"ANALYSIS-{int(time.time() * 1000)}"
        result_data = {
            "result": "Dat" if prediction == 1 else "Can cai thien",
            "prediction": prediction,
            "match_score": round(probability[1] * 10, 2),
            "match_percentage": match_percentage,
            "explanation": explanation,
            "feedback": build_human_feedback(text_cv, match_percentage, explanation),
            "debug": {
                "text_len": len(text_cv),
                "tfidf_dim": int(current_size),
                "final_dim": int(input_data_ready.shape[1]),
                "nonzero": nonzero
            }
        }
        ANALYSIS_STORE[analysis_id] = result_data

        return {"success": True, "analysisId": analysis_id, "data": result_data}
    except Exception as e:
        return {"success": False, "error": f"Execution error: {str(e)}"}


@app.get("/analysis/{analysis_id}")
async def get_analysis(analysis_id: str):
    stored = ANALYSIS_STORE.get(analysis_id)
    if not stored:
        return {"success": False, "message": "Not found analysis id"}
    return {"success": True, "analysisId": analysis_id, "data": stored}


@app.get("/analysis/{analysis_id}/explain")
async def get_analysis_explain(analysis_id: str):
    stored = ANALYSIS_STORE.get(analysis_id)
    if not stored:
        return {"success": False, "message": "Not found analysis id"}
    return {"success": True, "analysisId": analysis_id, "explanation": stored.get("explanation")}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)