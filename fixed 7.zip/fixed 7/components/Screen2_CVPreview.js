// ========================================
// Screen 2: CV Preview & Edit Component
// Displays CV data from backend and allows editing
// ========================================

const Screen2Component = {
    /**
     * Initialize Screen 2
     */
    async init() {
        if (Config.DEBUG) console.log('[Screen2] Initializing...');

        // Setup edit functionality
        if (Config.FEATURES.ALLOW_CV_EDIT) {
            this.setupEditButtons();
        }

        // Load data
        await this.loadCVData();
    },

    /**
     * Load CV data (Upload -> Extract)
     */
    async loadCVData() {
        try {
            // Show loading state in preview area
            const cvDocument = document.querySelector('#screen2 .cv-document');
            if (cvDocument) {
                cvDocument.innerHTML = `
                    <div class="processing-spinner"></div>
                    <p style="text-align: center;">Đang phân tích thông tin CV...</p>
                `;
            }

            // 1. Render Original PDF if available
            if (AppState.uploadedFile) {
                this.renderOriginalCV(AppState.uploadedFile);
            }

            // 2. Nếu Stage 1 đã trích xuất xong (Screen 1 gọi API upload ngay),
            //    thì chỉ cần render form từ AppState.parsedCVData.
            if (AppState.parsedCVData) {
                this.renderExtractedData(AppState.parsedCVData);
                AppState.confirmedCVData = AppState.parsedCVData;
                return;
            }

            // 3. Fallback (nếu vì lý do gì đó Screen 1 chưa gọi stage 1)
            if (!AppState.currentCVId && AppState.uploadedFile) {
                await CVAnalysisService.uploadCV(AppState.uploadedFile);
            }

            if (AppState.parsedCVData) {
                this.renderExtractedData(AppState.parsedCVData);
                AppState.confirmedCVData = AppState.parsedCVData;
            } else if (cvDocument && !AppState.uploadedFile) {
                cvDocument.innerHTML = '<p class="error">Chưa có file CV nào được tải lên.</p>';
            }

        } catch (error) {
            console.error('[Screen2] Error loading data:', error);
            // Don't overwrite PDF view if error is just in extraction
            if (!AppState.uploadedFile) {
                const cvDocument = document.querySelector('#screen2 .cv-document');
                if (cvDocument) cvDocument.innerHTML = `<p class="error">Lỗi: ${error.message}</p>`;
            } else {
                Helpers.showToast('Lỗi khi trích xuất dữ liệu: ' + error.message, 'error');
            }
        }
    },

    /**
     * Render Original CV PDF
     * @param {File} file - Uploaded file
     */
    renderOriginalCV(file) {
        const cvDocument = document.querySelector('#screen2 .cv-document');
        if (!cvDocument || !file) return;

        // Check if it's a PDF
        if (file.type === 'application/pdf') {
            const fileURL = URL.createObjectURL(file);
            cvDocument.innerHTML = `<iframe src="${fileURL}" width="100%" height="100%"></iframe>`;

            // Store URL to revoke later
            this.pdfUrl = fileURL;
        } else {
            // Fallback for non-PDF (though we validate in Screen 1)
            cvDocument.innerHTML = `
                <div style="padding: 20px; text-align: center; color: white;">
                    <p>File: ${Helpers.escapeHtml(file.name)}</p>
                    <p>Không thể hiển thị xem trước cho định dạng này.</p>
                </div>
            `;
        }
    },

    /**
     * Cleanup resources
     */
    cleanup() {
        if (this.pdfUrl) {
            URL.revokeObjectURL(this.pdfUrl);
            this.pdfUrl = null;
        }
    },

    /**
     * Render extracted data in form fields (called by backend)
     * @param {Object} data - Extracted CV data from backend
     */
    renderExtractedData(data) {
        if (!data) return;

        // Basic Info
        this.setFieldValue('input[data-field="name"]', data.basicInfo?.name);
        this.setFieldValue('input[data-field="email"]', data.basicInfo?.email);
        this.setFieldValue('input[data-field="phone"]', data.basicInfo?.phone);

        // Skills
        if (data.skills) {
            this.renderSkills(data.skills);
        }

        // Experience - hien thi full content
        if (data.experience && data.experience.length > 0) {
            const container = document.querySelector('#screen2 input[data-field="experience"]')?.closest('.form-group');
            if (container) {
                container.querySelectorAll('.extra-exp').forEach(el => el.remove());
                const firstInput = container.querySelector('input[data-field="experience"]');

                data.experience.forEach((exp, index) => {
                    const fullText = [
                        `${exp.duration || ''} | ${exp.title || ''} tại ${exp.company || ''}`,
                        exp.location ? `📍 ${exp.location}` : '',
                        exp.description ? exp.description : '',
                        exp.technologies && exp.technologies.length ? `Tech: ${exp.technologies.join(', ')}` : ''
                    ].filter(Boolean).join('\n');

                    if (index === 0) {
                        // Doi input thanh textarea cho dep
                        const textarea = document.createElement('textarea');
                        textarea.className = 'input-field';
                        textarea.style.cssText = 'width:100%;min-height:100px;resize:vertical;font-size:inherit;padding:8px;';
                        textarea.setAttribute('data-field', 'experience');
                        textarea.value = fullText;
                        firstInput.parentNode.replaceChild(textarea, firstInput);
                    } else {
                        const div = document.createElement('div');
                        div.className = 'editable-field mb-sm extra-exp';
                        div.style.marginTop = '8px';
                        const textarea = document.createElement('textarea');
                        textarea.className = 'input-field';
                        textarea.style.cssText = 'width:100%;min-height:100px;resize:vertical;font-size:inherit;padding:8px;';
                        textarea.setAttribute('data-field', 'experience');
                        textarea.value = fullText;
                        div.appendChild(textarea);
                        container.appendChild(div);
                    }
                });
            }
        }

        // Education
        if (data.education && data.education.length > 0) {
            const edu = data.education[0];
            const eduText = `${edu.degree || ''} ${edu.field || ''} - ${edu.institution || ''} (${edu.graduationYear || ''})`;
            this.setFieldValue('input[data-field="education"]', eduText.trim());
        }
    },

    /**
     * Set field value safely
     * @param {string} selector - Field selector
     * @param {string} value - Value to set
     */
    setFieldValue(selector, value) {
        const field = document.querySelector(`#screen2 ${selector}`);
        if (field && value) {
            field.value = value;
        }
    },

    /**
     * Render skills as tags
     * @param {Array} skills - Skills array
     */
    renderSkills(skills) {
        const container = document.querySelector('#screen2 .skills-container');
        if (!container || !skills) return;

        container.innerHTML = skills.map(skill => {
            const name = skill.name || skill;
            const confidence = skill.confidence || 100;
            return `
                <span class="tag ${confidence >= 90 ? 'tag-mint' : ''}" 
                      title="Độ tin cậy: ${confidence}%">
                    ${Helpers.escapeHtml(name)}
                </span>
            `;
        }).join('');
    },

    /**
     * Setup edit button functionality and event handlers
     */
    setupEditButtons() {
        // Edit buttons
        const editBtns = document.querySelectorAll('#screen2 .edit-btn');
        editBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const field = btn.previousElementSibling;
                if (field && field.tagName === 'INPUT') {
                    field.focus();
                    field.select();
                }
            });
        });

        // Track changes
        const inputs = document.querySelectorAll('#screen2 .editable-field input');
        inputs.forEach(input => {
            input.addEventListener('change', () => {
                AppState.cvModified = true;
            });
        });

        // Confirmation Checkbox
        const confirmCheckbox = document.getElementById('confirmDataCheckbox');
        const submitBtn = document.getElementById('btnSubmitCV');

        if (confirmCheckbox && submitBtn) {
            // Reset state
            confirmCheckbox.checked = false;
            submitBtn.disabled = true;

            confirmCheckbox.addEventListener('change', () => {
                submitBtn.disabled = !confirmCheckbox.checked;
            });
        }
    },

    /**
     * Get all field values for submission
     * @returns {Object} Current field values
     */
    getFormData() {
        const experienceEls = document.querySelectorAll('#screen2 [data-field="experience"]');
        const experience = Array.from(experienceEls)
            .map(el => el.value)
            .filter(v => v !== undefined && v !== null && String(v).trim().length > 0)
            .join('\n');

        return {
            basicInfo: {
                name: document.querySelector('#screen2 input[data-field="name"]')?.value,
                email: document.querySelector('#screen2 input[data-field="email"]')?.value,
                phone: document.querySelector('#screen2 input[data-field="phone"]')?.value
            },
            experience,
            education: document.querySelector('#screen2 input[data-field="education"]')?.value,
            confirmedAt: new Date().toISOString()
        };
    },

    /**
     * Validate form before submission
     * @returns {Object} Validation result
     */
    validate() {
        const data = this.getFormData();
        const errors = [];

        if (!data.basicInfo.name?.trim()) {
            errors.push('Vui lòng nhập tên');
        }

        if (!data.basicInfo.email?.trim() || !Helpers.isValidEmail(data.basicInfo.email)) {
            errors.push('Email không hợp lệ');
        }

        if (!data.basicInfo.phone?.trim()) {
            errors.push('Vui lòng nhập số điện thoại');
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Screen2Component;
}
