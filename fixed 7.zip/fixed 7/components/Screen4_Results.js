// ========================================
// Screen 4: Results Dashboard Component
// Displays AI analysis results from backend
// ========================================

const Screen4Component = {
    /**
     * Initialize Screen 4
     */
    async init() {
        if (Config.DEBUG) console.log('[Screen4] Initializing...');

        await this.loadResults();
    },

    /**
     * Load analysis results
     */
    async loadResults() {
        try {
            let result = null;

            // Uu tien doc tu AppState.analysisResult (da duoc Screen3 luu)
            if (AppState.analysisResult) {
                const a = AppState.analysisResult;
                result = {
                    status: (a.overallScore || a.matchScore || 0) >= 75 ? 'matched' : 'reviewed',
                    matchScore: a.overallScore || a.matchScore || 0,
                    message: a.recommendation || '',
                    strengths: a.strengths || [],
                    developmentAreas: a.concerns || a.developmentAreas || [],
                    explanation: a.note || a.explanation || 'Phan tich hoan tat.',
                    reviewedByHR: a.reviewedByHR || false
                };
            } else if (AppState.analysisId) {
                // Fallback: goi API neu chua co ket qua
                result = await CVAnalysisService.getResult(AppState.analysisId);
                AppState.analysisResult = result;
            } else {
                console.warn('[Screen4] No analysis result found');
                return;
            }

            if (result) {
                this.renderBanner(result.status === 'matched' || result.matchScore >= 80, result.message);
                this.renderGauge(result.matchScore);
                this.renderStrengths(result.strengths);
                this.renderDevelopmentAreas(result.developmentAreas);
                this.renderExplanation(result.explanation);
                this.renderHRConfirmation(result.reviewedByHR);
            }

        } catch (error) {
            console.error('[Screen4] Error loading results:', error);
            Helpers.showToast('Không thể tải kết quả phân tích', 'error');
        }
    },

    /**
     * Render result banner (called by backend)
     * @param {boolean} isSuccess - Whether candidate passed
     * @param {string} message - Custom message (optional)
     */
    renderBanner(isSuccess, message = null) {
        const banner = document.getElementById('resultBanner');
        if (!banner) return;

        banner.className = `result-banner ${isSuccess ? 'success' : 'rejected'}`;
        banner.innerHTML = isSuccess ? `
            <h2>
                <span>🎉</span>
                CHÚC MỪNG – BẠN ĐÃ PHÙ HỢP VỚI VỊ TRÍ
            </h2>
            <p>${message || 'Hồ sơ của bạn đã được đánh giá và xác nhận bởi bộ phận nhân sự'}</p>
        ` : `
            <h2>
                <span>📋</span>
                RẤT TIẾC – HỒ SƠ CHƯA PHÙ HỢP Ở THỜI ĐIỂM HIỆN TẠI
            </h2>
            <p>${message || 'Chúng tôi khuyến khích bạn ứng tuyển lại trong tương lai'}</p>
        `;
    },

    /**
     * Render circular gauge with score (called by backend)
     * @param {number} score - Match score (0-100)
     */
    renderGauge(score) {
        const gaugeCircle = document.querySelector('#screen4 .gauge-circle');
        const gaugeValue = document.querySelector('#screen4 .gauge-value');

        if (gaugeCircle) {
            gaugeCircle.style.setProperty('--percentage', score);
        }

        if (gaugeValue) {
            this.animateCounter(gaugeValue, 0, score, 1500);
        }
    },

    /**
     * Animate number counter
     * @param {HTMLElement} element - Element to update
     * @param {number} start - Start value
     * @param {number} end - End value
     * @param {number} duration - Animation duration (ms)
     */
    animateCounter(element, start, end, duration) {
        const startTime = performance.now();

        const update = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            // Ease out
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.round(start + (end - start) * easeOut);

            element.textContent = current + '%';

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        };

        requestAnimationFrame(update);
    },

    /**
     * Render strengths list (called by backend)
     * @param {Array} strengths - List of strength strings or objects
     */
    renderStrengths(strengths) {
        const list = document.getElementById('strengthsList');
        if (!list || !strengths) return;

        list.innerHTML = strengths.map(s => {
            const isObj = s && typeof s === 'object';
            const feature = isObj ? s.feature : null;
            const impact = isObj ? s.impact : null;
            const text = typeof s === 'string' ? s : (feature || s.title || '');
            const impactText = (typeof impact === 'number' || typeof impact === 'string') ? ` (${Number(impact).toFixed(3)})` : '';
            return `
                <li>
                    <span class="list-icon" style="color: var(--mint-teal);">✓</span>
                    <span>
                        <span class="tag tag-mint" style="margin-right: 8px;">
                            ${Helpers.escapeHtml(text)}
                        </span>
                        ${Helpers.escapeHtml(impactText)}
                    </span>
                </li>
            `;
        }).join('');
    },

    /**
     * Render development areas (called by backend)
     * @param {Array} areas - Development suggestion strings or objects
     */
    renderDevelopmentAreas(areas) {
        const list = document.getElementById('developmentList');
        if (!list || !areas) return;

        list.innerHTML = areas.map(a => {
            const isObj = a && typeof a === 'object';
            const feature = isObj ? a.feature : null;
            const impact = isObj ? a.impact : null;
            const text = typeof a === 'string' ? a : (feature || a.title || '');
            const impactText = (typeof impact === 'number' || typeof impact === 'string') ? ` (${Number(impact).toFixed(3)})` : '';
            return `
                <li>
                    <span class="list-icon" style="color: var(--sage-green);">→</span>
                    <span>
                        <span class="tag" style="
                            margin-right: 8px;
                            background: var(--error-red-bg);
                            color: var(--error-red);
                            border-color: var(--error-red);
                        ">
                            ${Helpers.escapeHtml(text)}
                        </span>
                        ${Helpers.escapeHtml(impactText)}
                    </span>
                </li>
            `;
        }).join('');
    },

    /**
     * Render AI explanation (called by backend)
     * @param {string} explanation - AI explanation text
     */
    renderExplanation(explanation) {
        const container = document.getElementById('explanationContent');
        if (!container || !explanation) return;

        // explanation can be string OR { base_score, top_positives, top_negatives }
        if (typeof explanation === 'string') {
            container.innerHTML = `<p>${Helpers.escapeHtml(explanation)}</p>`;
            return;
        }

        const base = (explanation.base_score !== undefined) ? explanation.base_score : null;
        const baseText = (base !== null) ? `Base score (XGBoost): ${Helpers.escapeHtml(String(base))}` : '';
        container.innerHTML = `
            <p>${baseText || 'Giải thích SHAP đã sẵn sàng.'}</p>
        `;
    },

    /**
     * Render HR confirmation status (called by backend)
     * @param {boolean} confirmed - Whether HR has confirmed
     * @param {string} message - Optional custom message
     */
    renderHRConfirmation(confirmed, message = null) {
        const container = document.getElementById('hrConfirmation');
        if (!container) return;

        if (confirmed) {
            container.innerHTML = `
                <span>✓</span>
                <span>${message || 'Kết quả này đã được bộ phận nhân sự xem xét và xác nhận'}</span>
            `;
        } else {
            container.innerHTML = `
                <span>⏳</span>
                <span>${message || 'Đang chờ bộ phận nhân sự xem xét'}</span>
            `;
            container.style.background = 'var(--sage-green-light)';
            container.style.color = 'var(--sage-green)';
        }
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Screen4Component;
}
